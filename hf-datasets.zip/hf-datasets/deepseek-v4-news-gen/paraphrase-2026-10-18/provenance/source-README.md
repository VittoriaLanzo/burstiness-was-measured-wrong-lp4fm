# New DeepSeek paraphrase generations — October 18, 2026

These are newly generated outputs, not recovered July 2026 data. They must not be presented as the original paraphrase experiment.

The frozen job list contains three instruction variants, the same 200 scenarios for each variant, and iteration 0: 600 article generations in total. All 600 selected successful rows are present, nonempty, unique, and have finish_reason=stop. No historical scorer has been applied.

The requested alias is deepseek-v4-pro, documented for this run as DeepSeek-V4-Pro-0813 (August 13). It is not a frozen July model version. Literal response model identifiers are preserved per row and in the manifest. This run uses max_tokens=32000 with thinking enabled and reasoning_effort=max, correcting the checked-in configuration's 16000-token budget. The original July paraphrase run's effective token cap cannot be proven.

Files include article text, reasoning where returned, token usage, response metadata, frozen prompts, attempt outcomes, and SHA-256 checksums. Private account balances, credentials, and local filesystem paths are excluded.

The initial submission process paused after one connection error with unavailable usage. A separately recorded continuation completed only the 112 previously untouched jobs; the failed request and its full conservative accounting reservation were preserved.

2 cells received one additional attempt after an empty, truncated, or transient-error result; no refusal or content-filter result was retried. The selected dataset contains 2 successful repair outputs. Every original and repair attempt is retained in the accompanying attempt records, with selected outputs explicitly linked to their attempt.

failed_cells.jsonl records historical failed attempts, including any subsequently repaired cells. run-summary.json distinguishes these from unresolved selected cells.

The dataset's existing baseline files are unchanged. This dated folder is a separate run.
