# HF dataset mirror (anonymized)

Local mirror of the HuggingFace datasets the paper's pipeline consumes, so every
scored evaluation can be reproduced end to end without dataset access.
Organization and dataset ids are masked as ANONYMIZED/... in the code for
double-blind review; this zip carries the actual files.

- paper-dataset/prompts_200_human.jsonl: the frozen human baseline. 200 Wikinews
  headlines (2016-2021, CC BY 2.5) paired with their human articles; the id field
  is the scenario_id used by every benchmark leg.
- ablation-corpus/burstiness_pairs.jsonl: the earlier paired ablation corpus
  fetched by experiments/ablation/build_ablation_corpus.py.
- <leg>-news-gen/<model>.jsonl: raw generations for the nine benchmark legs
  (5 modes x 3 samples x 200 scenarios per leg; released post-scrub revisions,
  thinking traces removed by bench/scrub_thinking.py where the model emitted
  them). qwen36-news-gen carries the file the paper was scored on (2,996 cells:
  four exceeded the reasoning budget and were excluded, Section 4.1).

- deepseek-v4-news-gen/benchmark-2026-10-18/deepseek-v4.jsonl: the DeepSeek V4 Pro
  leg regenerated on 18 October 2026 through the same API alias (documented that
  day as DeepSeek-V4-Pro-0813) with the same prompts and briefs; 3,000 rows, the
  paper's starred leg (deepseek-v4-pro-1018). Reasoning text removed; the full
  record with attempts, requests and manifests is on the dataset.
- deepseek-v4-news-gen/paraphrase-2026-10-18/variant_v{1,2,3}.jsonl: the
  instruction-wording probe run the same day against the same snapshot, 200 rows
  per paraphrase, one sample each (eval_prompt_id instruction_v1..v3).

Normalized variants regenerate deterministically from these raw files via
experiments/ablation/normalize_generation.py; scoring via
experiments/ablation/seed_avg_paired.py against the human baseline.

Identity screening: the only name-like matches in the generation text are
in-article third parties (e.g. quoted private citizens, public officials),
verified by hand and left intact.

Usage: unzip, then pass file paths to the scripts, e.g.
    python -m experiments.ablation.seed_avg_paired hf-datasets/paper-dataset/prompts_200_human.jsonl hf-datasets/qwen36-news-gen/qwen3.6-27b.jsonl qwen3.6-27b
