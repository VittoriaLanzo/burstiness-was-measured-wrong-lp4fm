---
license: cc-by-2.5
language:
- en
task_categories:
- text-generation
pretty_name: 'Sentence-Length Dispersion: Human Articles and Model Generations'
size_categories:
- 10K<n<100K
tags:
- burstiness
- sentence-length
- stylometry
- human-vs-machine
- news-generation
- prompting
configs:
- config_name: human_articles
  data_files: paper-dataset/prompts_200_human.jsonl
- config_name: qwen3.6-27b
  data_files: qwen36-news-gen/qwen3.6-27b.jsonl
- config_name: gemma-3-27b
  data_files: gemma3-news-gen/gemma-3-27b.jsonl
- config_name: deepseek-v4-pro
  data_files: deepseek-v4-news-gen/deepseek-v4.jsonl
- config_name: deepseek-v4-pro-2026-10-18
  data_files: deepseek-v4-news-gen/benchmark-2026-10-18/deepseek-v4.jsonl
- config_name: glm-5.2
  data_files: glm52-news-gen/glm-5.2.jsonl
- config_name: kimi-k2.6
  data_files: kimi26-news-gen/kimi-k2.6.jsonl
- config_name: grok-4.3
  data_files: grok43-news-gen/grok-4.3.jsonl
- config_name: grok-4.5
  data_files: grok45-news-gen/grok-4.5.jsonl
- config_name: gemini-3.1-pro
  data_files: gemini31-news-gen/gemini-3.1-pro.jsonl
- config_name: claude-opus-4.8
  data_files: opus48-news-gen/opus-4.8.jsonl
- config_name: paraphrase-2026-10-18
  data_files: deepseek-v4-news-gen/paraphrase-2026-10-18/variant_v*.jsonl
- config_name: ablation_corpus
  data_files: ablation-corpus/burstiness_pairs.jsonl
---

# Sentence-Length Dispersion: Human Articles and Model Generations

The data behind *Can Prompting Reliably Close the Sentence-Length Dispersion Gap?*
(Vittoria Lanzo and Dico Angelo, LP4FM workshop at NeurIPS 2026): the 200 human news
articles every model is scored against, the generations of the nine benchmarked models,
the DeepSeek V4 Pro leg re-run on 18 October 2026, the paraphrase probe run on the same
snapshot, and the earlier paired ablation corpus. Scoring code, prompts, scored
evaluations and the paper source are at
<https://github.com/VittoriaLanzo/burstiness-was-measured-wrong-lp4fm>.

## Contents

| path | rows | contents |
|---|---|---|
| `paper-dataset/prompts_200_human.jsonl` | 200 | Wikinews headlines (2016–2021, CC BY 2.5) with their human articles; its `id` is the `scenario_id` in every generation file |
| `<leg>-news-gen/<model>.jsonl` | 3,000 per leg (Qwen3.6-27B: 2,996; its four cells that exceeded the reasoning budget have no row) | generations of the nine benchmarked models: 200 headlines × 5 prompting modes × 3 samples |
| `deepseek-v4-news-gen/benchmark-2026-10-18/deepseek-v4.jsonl` | 3,000 | the DeepSeek V4 Pro grid re-run on 18 October 2026 through the API alias the July leg used, which then served a different checkpoint (documented that day as DeepSeek-V4-Pro-0813, a version dated 13 August, after the July run); DeepSeek V4 Pro† in the paper, reported beside the nine models and outside their counts |
| `deepseek-v4-news-gen/paraphrase-2026-10-18/variant_v{1,2,3}.jsonl` | 200 each | the instruction-wording probe on the same snapshot: three paraphrases of the instruction prompt, one sample per headline |
| `deepseek-v4-news-gen/*-2026-10-18/provenance/` | | the run records of each 18 October run: run manifest, run summary, repair and continuation records, the cell list (re-run) or job list (paraphrase probe), an appendix note, and the source dataset's README for the run |
| `ablation-corpus/burstiness_pairs.jsonl` | 100 | the earlier ablation corpus: 100 Wikinews articles (2016–2021, CC BY 2.5), each paired with one model-written article on the same headline (`human_text`, `ai_text`); its human side is the 100-article set on which `clean_wikinews.py` reproduces the shipped bodies exactly (Appendix D.1 of the paper) |
| `MANIFEST.json` | | every file's SHA-256, size, source dataset, source revision, source path and transformation, and each data file's row count |

Folders are named after the source datasets, except `ablation-corpus`, which holds
`burstiness-engine/burstiness-engine-ablation`. Legs (one model's grid each): Qwen3.6-27B (`qwen36`), Gemma 3 27B
(`gemma3`), DeepSeek V4 Pro (`deepseek-v4`), GLM-5.2 (`glm52`), Kimi K2.6 (`kimi26`),
Grok 4.3 (`grok43`), Grok 4.5 (`grok45`), Gemini 3.1 Pro (`gemini31`), Claude Opus 4.8
(`opus48`).

## Generation records

Each line is one generation. `scenario_id` joins it to the human article,
`eval_prompt_id` is the prompting mode (`control`, `instruction`, `fewshot`, `plan`,
`self_refine`; `instruction_v1`–`instruction_v3` in the paraphrase probe), `iteration` is
the sample (0–2) and `text` is the model's output as returned. The paper scores `text`
after uniform normalization (`experiments/ablation/normalize_generation.py` in the
repository), which regenerates the normalized text deterministically. An empty `text`
marks a refusal or a failed cell; per-leg completeness is in Appendix D.2 of the paper.
`reasoning` is empty in every generation file: reasoning text returned by a provider is not released.

## How this dataset was assembled

Every file is copied from one of the project's private working datasets under
`burstiness-engine`, at the revision recorded in `MANIFEST.json`. All files are byte-identical to their sources except the four
18 October generation files (the re-run grid and the three paraphrase variants), whose
`reasoning` field is emptied; every other field and the row order are unchanged.

Not included: reasoning text, and the per-attempt logs, which contain it; normalized
copies of the generations, which `normalize_generation.py` regenerates; evaluation JSONs
and multiplicity tables computed before the segmenter correction described in the paper
(the scored evaluations the paper reports are in the GitHub repository under
`experiments/results/`); smoke-test runs; and the outputs that `bench/scrub_thinking.py`
set aside because generation stopped inside the model's reasoning, whose cells were
regenerated.

The generations name people as news articles do (public officials, quoted members of the
public); these names are left as generated. The run records flag one retained off-topic output (DeepSeek V4 Pro†, self-refine,
scenario 93, iteration 1).

## Usage

```python
from datasets import load_dataset
human = load_dataset("burstiness-engine/sentence-length-dispersion", "human_articles", split="train")
gens = load_dataset("burstiness-engine/sentence-length-dispersion", "kimi-k2.6", split="train")
```

Scoring one leg against the human articles, from the root of a clone of the repository,
with `$D` a local download of this dataset
(`hf download burstiness-engine/sentence-length-dispersion --repo-type dataset --local-dir "$D"`):

```
python experiments/ablation/normalize_generation.py $D/kimi26-news-gen/kimi-k2.6.jsonl kimi-k2.6.jsonl
python -m experiments.ablation.seed_avg_paired $D/paper-dataset/prompts_200_human.jsonl kimi-k2.6.jsonl kimi-k2.6
```

This writes `seed_avg_paired_kimi-k2.6.json`, byte-identical to
`experiments/results/benchmark/kimi-k2.6/seed_avg_paired.json` in the repository. The
repository's `hf-datasets.zip` is a copy of this dataset.

## License

CC BY 2.5. The human articles are from English Wikinews (<https://en.wikinews.org>), by
Wikinews contributors under CC BY 2.5, reduced to plain article bodies (the parse is
described in Appendix D.1 of the paper).

## Citation

```bibtex
@inproceedings{lanzo2026dispersion,
  title     = {Can Prompting Reliably Close the Sentence-Length Dispersion Gap?},
  author    = {Lanzo, Vittoria and Angelo, Dico},
  booktitle = {Workshop on Linguistic Principles for Foundation Models (LP4FM), NeurIPS 2026},
  year      = {2026}
}
```

Cite the data with the revision you used:

```bibtex
@misc{lanzo2026dataset,
  title        = {{Sentence-Length Dispersion: Human Articles and Model Generations}},
  author       = {Lanzo, Vittoria and Angelo, Dico},
  howpublished = {Hugging Face dataset},
  year         = {2026},
  url          = {https://huggingface.co/datasets/burstiness-engine/sentence-length-dispersion}
}
```
