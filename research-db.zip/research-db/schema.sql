-- The Burstiness Engine — Postgres / Supabase schema
-- Logical model: sessions → queries → papers → findings ← learnings

CREATE TABLE IF NOT EXISTS sessions (
    id              SERIAL PRIMARY KEY,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at        TIMESTAMPTZ,
    label           TEXT NOT NULL,                  -- e.g. "pass-1-baseline", "pass-3-cutting-edge"
    notes           TEXT,
    isolation_mode  TEXT DEFAULT 'no-personal-carryover',
    notebook_id     TEXT
);

CREATE TABLE IF NOT EXISTS queries (
    id              SERIAL PRIMARY KEY,
    session_id      INT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    axis            TEXT NOT NULL,                  -- Q1..Q7, TTS-A, TTS-B, TTS-C, Bio, Arch
    query_text      TEXT NOT NULL,
    time_filter     TEXT,                           -- qdr:y, qdr:m, etc.
    source_engine   TEXT DEFAULT 'firecrawl',
    raw_output_path TEXT,                           -- path to firecrawl JSON
    executed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    result_count    INT
);

CREATE TABLE IF NOT EXISTS papers (
    id              SERIAL PRIMARY KEY,
    arxiv_id        TEXT UNIQUE,
    doi             TEXT UNIQUE,
    url             TEXT NOT NULL UNIQUE,
    title           TEXT NOT NULL,
    authors         TEXT,
    venue           TEXT,                           -- ACL, EMNLP, Interspeech, arXiv, eLife, etc.
    year            INT,
    peer_reviewed   BOOLEAN DEFAULT FALSE,
    abstract        TEXT,
    relevance_notes TEXT,
    first_seen_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    added_to_notebook BOOLEAN DEFAULT FALSE,
    notebook_source_id TEXT
);

-- Map papers to axes (many-to-many — a paper can bridge multiple questions)
CREATE TABLE IF NOT EXISTS paper_axes (
    paper_id        INT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
    axis            TEXT NOT NULL,
    bridge_paper    BOOLEAN DEFAULT FALSE,          -- true if relevant to ≥2 axes
    PRIMARY KEY (paper_id, axis)
);

-- Findings are session-level insights backed by papers
CREATE TABLE IF NOT EXISTS findings (
    id              SERIAL PRIMARY KEY,
    session_id      INT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    axis            TEXT NOT NULL,
    finding_type    TEXT DEFAULT 'general',         -- general, gap, competing-work, methodology, perception
    finding_text    TEXT NOT NULL,
    confidence      TEXT DEFAULT 'medium',          -- low, medium, high
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS finding_papers (
    finding_id      INT NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
    paper_id        INT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
    PRIMARY KEY (finding_id, paper_id)
);

-- Learnings are cross-session, compounding insights about the project itself
CREATE TABLE IF NOT EXISTS learnings (
    id              SERIAL PRIMARY KEY,
    category        TEXT NOT NULL,                  -- methodology, novelty-bar, gap, competing, perception, bio
    statement       TEXT NOT NULL,
    why             TEXT,
    how_to_apply    TEXT,
    derived_from_sessions JSONB DEFAULT '[]',       -- JSON array of session ids (mirrors SQLite)
    superseded_by   INT REFERENCES learnings(id),   -- for evolution tracking
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- A/B comparison: track when a cutting-edge paper supersedes/extends an older one
CREATE TABLE IF NOT EXISTS paper_progression (
    id              SERIAL PRIMARY KEY,
    older_paper_id  INT NOT NULL REFERENCES papers(id),
    newer_paper_id  INT NOT NULL REFERENCES papers(id),
    relation        TEXT NOT NULL,                  -- extends, supersedes, contradicts, complements
    delta_summary   TEXT,
    detected_in_session INT REFERENCES sessions(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_papers_arxiv ON papers(arxiv_id);
CREATE INDEX IF NOT EXISTS idx_paper_axes_axis ON paper_axes(axis);
CREATE INDEX IF NOT EXISTS idx_findings_session ON findings(session_id);
CREATE INDEX IF NOT EXISTS idx_findings_axis ON findings(axis);
CREATE INDEX IF NOT EXISTS idx_learnings_category ON learnings(category);
