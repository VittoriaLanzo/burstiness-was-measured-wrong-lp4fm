-- The Burstiness Engine — SQLite schema (fallback when Supabase unavailable)
-- Same logical model as schema.sql, adapted for SQLite

CREATE TABLE IF NOT EXISTS sessions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at      TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at        TEXT,
    label           TEXT NOT NULL,
    notes           TEXT,
    isolation_mode  TEXT DEFAULT 'no-personal-carryover',
    notebook_id     TEXT
);

CREATE TABLE IF NOT EXISTS queries (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    axis            TEXT NOT NULL,
    query_text      TEXT NOT NULL,
    time_filter     TEXT,
    source_engine   TEXT DEFAULT 'firecrawl',
    raw_output_path TEXT,
    executed_at     TEXT NOT NULL DEFAULT (datetime('now')),
    result_count    INTEGER
);

CREATE TABLE IF NOT EXISTS papers (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    arxiv_id            TEXT UNIQUE,
    doi                 TEXT UNIQUE,
    url                 TEXT NOT NULL UNIQUE,
    title               TEXT NOT NULL,
    authors             TEXT,
    venue               TEXT,
    year                INTEGER,
    peer_reviewed       INTEGER DEFAULT 0,
    abstract            TEXT,
    relevance_notes     TEXT,
    first_seen_at       TEXT NOT NULL DEFAULT (datetime('now')),
    added_to_notebook   INTEGER DEFAULT 0,
    notebook_source_id  TEXT
);

CREATE TABLE IF NOT EXISTS paper_axes (
    paper_id        INTEGER NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
    axis            TEXT NOT NULL,
    bridge_paper    INTEGER DEFAULT 0,
    PRIMARY KEY (paper_id, axis)
);

CREATE TABLE IF NOT EXISTS findings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    axis            TEXT NOT NULL,
    finding_type    TEXT DEFAULT 'general',
    finding_text    TEXT NOT NULL,
    confidence      TEXT DEFAULT 'medium',
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS finding_papers (
    finding_id      INTEGER NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
    paper_id        INTEGER NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
    PRIMARY KEY (finding_id, paper_id)
);

CREATE TABLE IF NOT EXISTS learnings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    category        TEXT NOT NULL,
    statement       TEXT NOT NULL,
    why             TEXT,
    how_to_apply    TEXT,
    derived_from_sessions TEXT DEFAULT '[]',         -- JSON array of session ids
    superseded_by   INTEGER REFERENCES learnings(id),
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS paper_progression (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    older_paper_id          INTEGER NOT NULL REFERENCES papers(id),
    newer_paper_id          INTEGER NOT NULL REFERENCES papers(id),
    relation                TEXT NOT NULL,
    delta_summary           TEXT,
    detected_in_session     INTEGER REFERENCES sessions(id),
    created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_papers_arxiv ON papers(arxiv_id);
CREATE INDEX IF NOT EXISTS idx_paper_axes_axis ON paper_axes(axis);
CREATE INDEX IF NOT EXISTS idx_findings_session ON findings(session_id);
CREATE INDEX IF NOT EXISTS idx_findings_axis ON findings(axis);
CREATE INDEX IF NOT EXISTS idx_learnings_category ON learnings(category);
