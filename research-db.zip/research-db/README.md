# Research-corpus database (anonymized)

The SQLite research corpus behind the paper's literature curation: papers (verified
arXiv ids), queries, findings, learnings, and research-session provenance. The
bibliography and the related-work corpus derive from it.

- burstiness.db: the built database (SQLite). Author names are masked as
  Author A / Author B; the cited third-party author names in paper records are real.
- seed.py: the hand-curated seed that regenerates the database from scratch
  (single source of truth; python seed.py rebuilds it).
- schema.sqlite.sql: the runtime SQLite schema. schema.sql: the portable
  Postgres mirror kept in parity.

The database was scrubbed cell-by-cell and VACUUMed, so no pre-scrub strings
remain in free pages.
