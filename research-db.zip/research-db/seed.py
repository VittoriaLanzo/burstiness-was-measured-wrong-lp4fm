#!/usr/bin/env python3
"""
Seed the research-corpus DB with findings from pass 1+2+3.
Defaults to SQLite at db/burstiness.db. Set SUPABASE_URL + SUPABASE_SERVICE_KEY
in .env to write to Postgres instead.

Usage:
    python3 db/seed.py                  # apply schema + load all passes
    python3 db/seed.py --reset          # drop and recreate
"""
from __future__ import annotations
import json, os, sqlite3, sys, argparse
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
SQLITE_PATH = Path(os.environ.get("SQLITE_PATH", ROOT / "db" / "burstiness.db"))
SCHEMA = ROOT / "db" / "schema.sqlite.sql"

# (axis, query_text, time_filter, raw_output_path) for queries we already ran
PASS1_2_QUERIES = [
    ("Q2,Q4",   "controllable text generation LoRA style adapter frozen LLM stylistic steering arXiv", None, "data/firecrawl/q1-lora-steering.json"),
    ("TTS-A",   "Raitio Apple controllable prosody TTS conditioning CTRL-P prosodic speech synthesis", None, "data/firecrawl/q2-tts-prosody.json"),
    ("Q5,Q7",   "burstiness sentence length variance perplexity AI generated text detection GPTZero stylometry", None, "data/firecrawl/q3-burstiness-detection.json"),
    ("Q6",      "stylometric fingerprint authorship attribution sentence rhythm English prose Mendenhall", None, "data/firecrawl/q4-stylometry-fingerprint.json"),
    ("Q3",      "AI generated text burstiness longitudinal GPT-3 GPT-4 stylistic evolution detection across model generations", None, "data/firecrawl/q5-temporal-trend.json"),
    ("Q1,Q7",   "prompt engineering ceiling stylistic distributional control LLM negative results long output drift punctuation paragraph rhythm", None, "data/firecrawl/q6-prompt-ceiling.json"),
    ("TTS-C",   "Bakkouche prosody perception Interspeech 2025 TTS speech synthesis listener", None, "data/firecrawl/q7-bakkouche.json"),
    ("Bio,Arch","neural oscillations language predictive coding speech rhythm thought chunking transformer attention prosody biology Pickering Garrod", None, "data/firecrawl/q8-bio-arch.json"),
]

PASS3_QUERIES = [
    ("Q2,Q4",   "controllable text generation LoRA style adapter 2025 frozen LLM activation steering", "qdr:y", "data/firecrawl/pass3-q1-cutting-edge-steering.json"),
    ("Q3,Q5",   "burstiness LLM text generation 2025 2026 stylometric variance peer-reviewed EMNLP ACL NAACL", "qdr:y", "data/firecrawl/pass3-q2-cutting-edge-burstiness.json"),
    ("TTS-A",   "prosody control TTS 2025 NaturalSpeech VALL-E neural speech synthesis variance adaptor latent", "qdr:y", "data/firecrawl/pass3-q3-cutting-edge-tts.json"),
    ("Q3,Q5",   "AI generated text detection 2025 2026 burstiness perplexity DetectGPT Binoculars latest", "qdr:y", "data/firecrawl/pass3-q4-cutting-edge-detection.json"),
]

PASS4_QUERIES = [
    ("Q1",    "prompt-only stylistic control distributional ceiling negative results LLM sentence length variance kurtosis", "qdr:y", "data/firecrawl/pass4-q1-ceiling.json"),
    ("Q7",    "punctuation paragraph rhythm proxy text generation LLM burstiness sentence segmentation", "qdr:y", "data/firecrawl/pass4-q7-punct.json"),
    ("Q7",    "punctuation as proxy for sentence rhythm stylometry text segmentation author attribution", None, "data/firecrawl/pass4-q7-punct-all.json"),
    ("TTS-B", "Wagner Klimkov CTRL-P prosodic boundaries phrasing prominence ICASSP text-to-speech", None, "data/firecrawl/pass4-ctrlp.json"),
]

# Hand-curated papers (full citation list from pass 1+2+3)
# Format: (arxiv_id, doi, url, title, authors, venue, year, peer_reviewed, axes, bridge, notes)
PAPERS = [
    # ===== Pass 1+2 =====
    ("2402.01618", None, "https://arxiv.org/abs/2402.01618", "Style Vectors for Steering Generative Large Language Models", "Kai Konen and Sophie Jentzsch and Diaoulé Diallo and Peer Schütt and Oliver Bensch and Roxanne El Baff and Dominik Opitz and Tobias Hecking", "EACL 2024 Findings", 2024, True, ["Q2","Q4","Q6"], True, "Foundational steering template for a 'burstiness vector'"),
    ("2503.05213", None, "https://arxiv.org/abs/2503.05213", "Personalized Text Generation with Contrastive Activation Steering", "Jinghao Zhang and Yuting Liu and Wenjie Wang and Qiang Liu and Shu Wu and Liang Wang and Tat-Seng Chua", "arXiv", 2025, False, ["Q4","Q6"], True, "User-specific style vectors via contrastive activation — closest analogue to a personal burstiness fingerprint"),
    ("2601.06352", None, "https://arxiv.org/abs/2601.06352", "CARD: Cluster-level Adaptation with Reward-guided Decoding for Personalized Text Generation", "Yutong Song and Jiang Wu and Weijia Zhang and Chengze Shen and Shaofan Yuan and Weitao Lu and Jian Wang and Yu Wang and Nikil Dutt and Amir M. Rahmani", "arXiv", 2026, False, ["Q4"], False, "Logit corrections on frozen LLM"),
    ("2404.07117", None, "https://arxiv.org/abs/2404.07117", "Continuous Language Model Interpolation for Dynamic and Controllable Text Generation", "Sara Kangaslahti and David Alvarez-Melis", "arXiv", 2024, False, ["Q4"], False, "Weight-space interpolation for fine-grained control"),
    ("2408.15666", None, "https://arxiv.org/abs/2408.15666", "StyleRemix: Interpretable Authorship Obfuscation via Distillation and Perturbation of Style Elements", "Jillian Fisher and Skyler Hallinan and Ximing Lu and Mitchell Gordon and Zaid Harchaoui and Yejin Choi", "arXiv", 2024, False, ["Q4","Q6"], True, "Reverse of burstiness-injection — same machinery"),
    ("2601.06362", None, "https://arxiv.org/abs/2601.06362", "Styles + Persona-plug = Customized LLMs", "Yutong Song and Jiang Wu and Shaofan Yuan and Chengze Shen and Jian Wang and Amir Rahmani and Nikil Dutt and Yu Wang", "arXiv", 2026, False, ["Q4"], False, "Plug-in persona over frozen LLM"),
    ("2503.16334", None, "https://arxiv.org/abs/2503.16334", "LLM Braces: Straightening Out LLM Predictions with Relevant Sub-Updates", "Ying Shen and Lifu Huang", "arXiv", 2025, False, ["Q2"], False, "Task-specific control via relevant sub-updates"),

    # ===== Pass 6: v2 controller method lineage (boundary-FUDGE) =====
    ("2104.05218", None, "https://arxiv.org/abs/2104.05218", "FUDGE: Controlled Text Generation With Future Discriminators", "Kevin Yang and Dan Klein", "NAACL 2021", 2021, True, ["Q4"], True, "Foundation for boundary-FUDGE: future-attribute discriminator-guided decoding. We adapt it by using the computable burstiness metric as the future predictor applied only to the sentence-boundary decision."),
    ("2606.05889", None, "https://arxiv.org/abs/2606.05889", "GLASS: GRPO-Trained LoRA for Acoustic Style Steering in Zero-Shot TTS", "Jaehoon Kang and Yejin Lee and Kyuhong Shim", "arXiv", 2026, False, ["Q4","TTS-A"], False, "GRPO-trained LoRA for a continuous style attribute - method analogue for the GRPO burstiness controller arm."),
    ("2602.03826", None, "https://arxiv.org/abs/2602.03826", "Continuous Control of Editing Models via Adaptive-Origin Guidance", "Alon Wolf and Chen Katzir and Kfir Aberman and Or Patashnik", "arXiv", 2026, False, ["Q4"], False, "Continuous control via guidance - relevant to the smooth burstiness dial."),
    ("2601.22708", None, "https://arxiv.org/abs/2601.22708", "A Unified Study of LoRA Variants: Taxonomy, Review, Codebase", "Haonan He and Jingqi Ye and Minglei Li and Zhengbo Wang and Tao Chen and Lei Bai and Peng Ye", "arXiv", 2026, False, ["Q4"], False, "LoRA-variant taxonomy - reference for the controller adapter choice."),

    # ===== Pass 7: scoop-defense (closest prior art on the mechanism axis) =====
    ("2007.14966", None, "https://arxiv.org/abs/2007.14966", "Mirostat: A Neural Text Decoding Algorithm that Directly Controls Perplexity", "Sourya Basu and Govardana Sachitanandam Ramachandran and Nitish Shirish Keskar and Lav R. Varshney", "ICLR 2021", 2021, True, ["Q4"], True, "MUST-DIFFERENTIATE (top scoop risk): controls a distributional output statistic (perplexity) in-generation via closed-form feedback. We differ: structural sequence-VARIANCE not token-mean; boundary-only not whole-vocab; future-discriminator not running set-point. Frame ours as the structural-variance, boundary-altitude generalization."),
    ("2305.10847", None, "https://arxiv.org/abs/2305.10847", "Large Language Models can be Guided to Evade AI-Generated Text Detection", "Ning Lu and Shengcai Liu and Rui He and Qi Wang and Yew-Soon Ong and Ke Tang", "TMLR 2024", 2024, False, ["Q4","Q6"], False, "Forces sentence-length variance for detector evasion via prompt/in-context substitution: black-box, post-hoc, no logit steering. Cite-and-dismiss as orthogonal humanizer mechanism."),
    ("2510.03782", None, "https://arxiv.org/abs/2510.03782", "Merge and Guide: Unifying Model Merging and Guided Decoding for Controllable Multi-Objective Generation", "Guofu Xie and Chen Zhang and Xiao Zhang and Yunsheng Shi and Ting Yao and Jun Xu", "arXiv", 2025, False, ["Q4"], False, "Closed-form logit-combination decoding for semantic/reward objectives, not structural statistics: shows the closed-form-decoding family does not cover structural-variance."),

    ("2009.06775", None, "https://arxiv.org/abs/2009.06775", "Controllable neural text-to-speech synthesis using intuitive prosodic features", "Tuomo Raitio and Ramya Rasipuram and Dan Castellani", "Interspeech 2020", 2020, True, ["TTS-A","Q2"], True, "The Raitio paper Author A named"),
    ("2110.03012", None, "https://arxiv.org/abs/2110.03012", "Emphasis control for parallel neural TTS", "Shreyas Seshadri and Tuomo Raitio and Dan Castellani and Jiangchuan Li", "Interspeech 2022", 2022, True, ["TTS-A"], False, "Hierarchical latent space for prosodic emphasis"),
    (None, "10.21437/interspeech.2025-947", "https://doi.org/10.21437/interspeech.2025-947", "Finding the Human Voice in AI: Insights on the Perception of AI-Voice Clones from Naturalness and Similarity Ratings", "Linda Bakkouche and Charles McGhee and Emily Lau and Stephanie Cooper and Xinbing Luo and Madeleine Rees and Kai Alter and Brechtje Post and Julia Schwarz", "Interspeech 2025", 2025, True, ["TTS-C","Q6"], True, "The named Bakkouche perception study — listeners discriminate human vs AI voice clones by prosody/naturalness"),

    ("2507.10475", None, "https://arxiv.org/abs/2507.10475", "Can You Detect the Difference?", "Tarım, İsmail and Onan, Aytuğ", "arXiv", 2025, False, ["Q5","Q3"], True, "COMPETING WORK — first systematic stylometric burstiness comparison. Cite, don't ignore."),
    ("2501.19301", None, "https://arxiv.org/abs/2501.19301", "Beyond Checkmate: Creative Choke Points in AI Text", "Nafis Irtiza Tripto and Saranya Venkatraman and Mahjabin Nahar and Dongwon Lee", "arXiv", 2025, False, ["Q5"], False, "Segment-level burstiness analysis — where the rhythm signal lives"),
    ("2406.15583", None, "https://arxiv.org/abs/2406.15583", "Detecting AI-Generated Text: Factors Influencing Detectability with Current Methods", "Kathleen C. Fraser and Hillary Dawkins and Svetlana Kiritchenko", "arXiv", 2024, False, ["Q5"], False, "Survey treating perplexity-burstiness as standard"),
    ("2506.17196", None, "https://arxiv.org/abs/2506.17196", "Detecting LLM-Generated Short Answers and Effects on Learner Performance", "Shambhavi Bhushan and Danielle R Thomas and Conrad Borchers and Isha Raghuvanshi and Ralph Abboud and Erin Gatz and Shivang Gupta and Kenneth Koedinger", "arXiv", 2025, False, ["Q5"], False, "Documents GPTZero operationalization"),
    ("2501.02406", None, "https://arxiv.org/abs/2501.02406", "A Training-free Method for LLM Text Attribution", "Tara Radvand and Mojtaba Abdolmaleki and Mohamed Mostagir and Ambuj Tewari", "arXiv", 2025, False, ["Q5"], False, "Uses GPTZero burstiness definition upstream"),

    ("2307.09009", None, "https://arxiv.org/abs/2307.09009", "How is ChatGPT's Behavior Changing Over Time?", "Lingjiao Chen and Matei Zaharia and James Zou", "Harvard Data Science Review", 2024, True, ["Q3"], False, "Empirical longitudinal drift of LLM behavior"),
    (None, "10.1016/j.compedu.2026.105616", "https://www.sciencedirect.com/science/article/pii/S0360131526000540", "Trusting AI to detect AI?", "Yicheng Sun and Yihan Liao and Xiaoxue Ma", "Computers & Education", 2026, True, ["Q3"], False, "Detection rates drop with newer LLM generations"),
    (None, None, "https://pmc.ncbi.nlm.nih.gov/articles/PMC10411719/", "Distinguishing ChatGPT(-3.5, -4)-generated and human-written papers through Japanese stylometric analysis", "Wataru Zaitsu and Mingzhe Jin", "PLoS One", 2023, True, ["Q3"], False, "Direct stylometric comparison across GPT versions"),
    ("2509.22055", None, "https://arxiv.org/abs/2509.22055", "RedNote-Vibe: Temporal Dynamics of AI-Generated Text", "Yudong Li and Yufei Sun and Peiru Yang and Yuhan Yao and Wanyue Li and Jiajun Zou and Haoyang Yang and Haotian Gan and Linlin Shen and Yongfeng Huang", "arXiv", 2025, False, ["Q3"], False, "Dataset for temporal-dynamics detection"),

    (None, "10.7554/eLife.91636", "https://elifesciences.org/reviewed-preprints/91636v1", "Language experience shapes predictive coding of rhythmic sound sequences", "Piermatteo Morucci and Sanjeev Nara and Mikel Lizarazu and Clara Martin and Nicola Molinaro", "eLife", 2024, True, ["Bio"], False, "Brain rhythm-prediction is shaped by native-language experience"),
    ("2111.14232", None, "https://arxiv.org/abs/2111.14232", "Long-range and hierarchical language predictions in brains and algorithms", "Charlotte Caucheteux and Alexandre Gramfort and Jean-Remi King", "Nature Human Behaviour", 2023, True, ["Bio","Arch"], True, "LM hierarchy matches brain hierarchy — strongest Vaswani↔biology bridge"),
    ("2206.01685", None, "https://arxiv.org/abs/2206.01685", "Toward a realistic model of speech processing in the brain with SSL", "Juliette Millet and Charlotte Caucheteux and Pierre Orhan and Yves Boubenec and Alexandre Gramfort and Ewan Dunbar and Christophe Pallier and Jean-Remi King", "arXiv", 2022, False, ["Bio"], False, "SSL models match brain processing"),
    (None, None, "https://pmc.ncbi.nlm.nih.gov/articles/PMC11025645/", "Predictive Coding or Just Feature Discovery? An Alternative Account", "Richard Antonello and Alexander Huth", "Neurobiology of Language", 2023, True, ["Bio"], False, "Critical view — LM features predict brain but mechanism may not be predictive coding"),

    # ===== Pass 3 cutting-edge =====
    ("2509.18880", None, "https://arxiv.org/abs/2509.18880", "Diversity Boosts AI-Generated Text Detection", "Advik Raj Basani and Pin-Yu Chen", "arXiv", 2025, False, ["Q5","Q3"], True, "CUTTING-EDGE — surprisal-based features capturing how unpredictability FLUCTUATES across text. Most direct burstiness-adjacent 2025 work. Author A pole-position read."),
    (None, None, "https://aclanthology.org/2025.emnlp-main.40.pdf", "Towards Controllable Speech Synthesis in the Era of LLMs", "Lee et al.", "EMNLP 2025 main", 2025, True, ["TTS-A","Q2"], True, "EMNLP 2025 unified TTS+LLM control framework. Cites DiTTo-TTS for speech rate via latent length."),
    ("2604.14090", None, "https://arxiv.org/abs/2604.14090", "From Weights to Activations: Is Steering the Next Frontier of Adaptation?", "Simon Ostermann and Daniil Gurgurov and Tanja Baeumel and Michael A. Hedderich and Sebastian Lapuschkin and Wojciech Samek and Vera Schmitt", "arXiv", 2026, False, ["Q2","Q4"], False, "2025/2026 survey-style — situates activation steering as the next frontier"),
    ("2602.11910", None, "https://arxiv.org/abs/2602.11910", "TADA! Tuning Audio Diffusion Models through Activation Steering", "Łukasz Staniszewski and Katarzyna Zaleska and Mateusz Modrzejewski and Kamil Deja", "arXiv", 2026, False, ["Q4","TTS-A"], True, "Activation steering applied to audio diffusion"),
    ("2601.07473", None, "https://arxiv.org/abs/2601.07473", "Self-Supervised Honesty Steering via Anti-Parallel Representations", "Michael J. Clark", "arXiv", 2026, False, ["Q4"], False, "Self-supervised steering method"),
    ("2501.00365", None, "https://arxiv.org/abs/2501.00365", "Low-Rank Adaptation for Foundation Models: A Comprehensive Review", "Menglin Yang and Jialin Chen and Jinkai Tao and Yifei Zhang and Jiahong Liu and Jiasheng Zhang and Qiyao Ma and Harshit Verma and Regina Zhang and Min Zhou and others", "arXiv", 2024, False, ["Q2","Q4"], False, "Comprehensive LoRA survey"),
    ("2605.18474", None, "https://arxiv.org/abs/2605.18474", "Prompt2Fingerprint: Plug-and-Play LLM Fingerprinting via Text-to-Weight Generation", "Sixu Chen and Xiang Chen and Hongyao Yu and Jiaxin Hong and Hao Fang and Shuoyang Sun and Bin Chen and Shu-Tao Xia", "arXiv", 2026, False, ["Q4","Q6"], True, "GENERATES LoRA params as variable-length sequences — direct precedent for personalized burstiness-LoRA generation"),
    ("2602.18152", None, "https://arxiv.org/abs/2602.18152", "The Statistical Signature of LLMs", "Ortal Hadad and Edoardo Loru and Jacopo Nudo and Niccolò Di Marco and Matteo Cinelli and Walter Quattrociocchi", "arXiv", 2026, False, ["Q5"], False, "How probabilistic sampling reshapes statistical structure"),
    (None, None, "https://www.sciencedirect.com/org/science/article/pii/S1546221826000482", "AI-Generated Text Detection: A Comprehensive Review of Active and Passive Approaches", "Lingyun Xiang and Nian Li and Yuling Liu and Jiayong Hu", "Computers, Materials & Continua", 2025, True, ["Q5"], False, "2025/26 detection review — paraphrasing vulnerability"),
    (None, None, "https://researchportal.helsinki.fi/files/801728740/suni25_ssw.pdf", "Style and Prosody control for Zero-shot Speech Synthesis", "Suni, Antti et al.", "SSW 2025", 2025, True, ["TTS-A"], False, "Derived-vector approach to predictably modify synthesized speech"),
    (None, "10.1145/3749644", "https://dl.acm.org/doi/full/10.1145/3749644", "Enhanced Prosody Modeling and Character Voice Controlling for Audiobook Speech Synthesis", "Ning-Qian Wu and Zhen-Hua Ling", "ACM Transactions on Asian and Low-Resource Language Information Processing", 2025, True, ["TTS-A"], False, "Prosodic expressiveness for audiobook synthesis"),
    ("2604.21164", None, "https://arxiv.org/abs/2604.21164", "MAGIC-TTS: Fine-Grained Controllable Speech Synthesis", "Jialong Mai and Xiaofen Xing and Xiangmin Xu", "arXiv", 2026, False, ["TTS-A"], False, "Token-level duration conditioning"),
    ("2605.17583", None, "https://arxiv.org/abs/2605.17583", "AgentSteerTTS: Multi-Agent Closed-Loop TTS Steering", "Bin Kang and Shaoguo Wen and Yang Fan and Shunlong Wu and Junjie Wang and Yulin Li and Junzhi Zhao and Junle Wang and Zhuotao Tian", "arXiv", 2026, False, ["TTS-A","Q4"], True, "Multi-agent closed-loop steering — adversarial disentanglement"),

    # ===== Pass 4 — closing Q1 / Q7 / CTRL-P =====
    ("2509.10179", None, "https://arxiv.org/abs/2509.10179", "Benchmark of Stylistic Variation in LLM-Generated Texts", "Jiří Milička and Anna Marklová and Václav Cvrček", "arXiv", 2025, False, ["Q1","Q3"], True, "COMPETING WORK for Q1 — benchmarks stylistic variation across 16 frontier models + prompt settings. Does NOT frame as control ceiling vs distributional target — wedge survives but must differentiate."),
    ("2504.12522", None, "https://arxiv.org/abs/2504.12522", "Evaluating the Diversity and Quality of LLM Generated Content", "Alexander Shypula and Shuo Li and Botong Zhang and Vishakh Padmakumar and Kayo Yin and Osbert Bastani", "arXiv", 2025, False, ["Q1","Q3"], False, "Effective semantic diversity = diversity among quality-passing outputs. Method gift: gate burstiness measurement on quality so high-variance incoherence isn't rewarded."),
    ("2509.14543", None, "https://arxiv.org/abs/2509.14543", "LLMs Still Struggle to Imitate the Implicit Writing Styles of Everyday People", "Zhengxiang Wang and Nafis Irtiza Tripto and Solha Park and Zhenzhen Li and Jiawei Zhou", "arXiv", 2025, False, ["Q1","Q6"], True, "Prompt-only personalized-style imitation FAILS — dual support for Q1 (prompt ceiling) and Q6 (fingerprint hard by instruction). Strongest single motivation for model-level approach."),
    (None, None, "https://pmc.ncbi.nlm.nih.gov/articles/PMC12415252/", "Echoes in AI: Quantifying Lack of Plot Diversity in LLM Outputs", "Weijia Xu and Nebojsa Jojic and Sudha Rao and Chris Brockett", "PNAS", 2025, True, ["Q3","Q1"], False, "Quantifies diversity collapse in LLM outputs — supports cross-generation flattening / 'average prosody' in text."),
    ("2507.00838", None, "https://arxiv.org/abs/2507.00838", "Stylometry Recognizes Human and LLM-Generated Texts", "Karol Przystalski and Jan K. Argasiński and Iwona Grabska-Gradzińska and Jeremi K. Ochab", "arXiv", 2025, False, ["Q5","Q6"], False, "Stylometric human-vs-LLM discrimination — burstiness sits inside a working stylometric feature set."),
    ("2106.08352", None, "https://arxiv.org/abs/2106.08352", "Ctrl-P: Temporal Control of Prosodic Variation for Speech Synthesis", "Devang S Ram Mohan and Vivian Hu and Tian Huey Teh and Alexandra Torresquintero and Christopher G. R. Wallis and Marlene Staib and Lorenzo Foglianti and Jiameng Gao and Simon King", "Interspeech 2021", 2021, True, ["TTS-B"], False, "RESOLVED: the true 'CTRL-P' Author A referenced, distinct from Raitio 2020. Conditions on three acoustic correlates of prosody. PHASE 2 anchor, not core."),
    ("2604.20221", None, "https://arxiv.org/abs/2604.20221", "A Statistical Journey into the Poetic World of Evgenij Onegin", "Angelo Maria Sabatini", "arXiv", 2026, False, ["Q7"], False, "Symbolic time-series + Markov modeling of phonological rhythm. Method transfer for Q7: model punctuation/segmentation as a symbolic time series → timing-free burstiness proxy."),

    # ===== Prompt-ceiling benchmark: prompting-method templates (Q1) =====
    ("2406.06608", None, "https://arxiv.org/abs/2406.06608", "The Prompt Report: A Systematic Survey of Prompt Engineering Techniques", "Sander Schulhoff and Michael Ilie and Nishant Balepur and others", "arXiv", 2024, False, ["Q1"], True, "Taxonomy anchor: its 6 families define the non-overlapping mechanism coverage (tell/show/plan/fix/select) for the prompt-ceiling conditions; the fairness guarantee is coverage at the mechanism level, not technique names."),
    ("2302.11382", None, "https://arxiv.org/abs/2302.11382", "A Prompt Pattern Catalog to Enhance Prompt Engineering with ChatGPT", "Jules White and Quchen Fu and Sam Hays and Michael Sandborn and Carlos Olea and Henry Gilbert and Ashraf Elnashar and Jesse Spencer-Smith and Douglas C. Schmidt", "arXiv", 2023, False, ["Q1"], True, "The Persona Pattern ('Act as persona X') is the canonical, metric-free role template adopted verbatim for the M1 instruction condition."),
    ("2005.14165", None, "https://arxiv.org/abs/2005.14165", "Language Models are Few-Shot Learners", "Tom B. Brown and Benjamin Mann and Nick Ryder and others", "NeurIPS 2020", 2020, True, ["Q1"], True, "Few-shot / in-context learning foundation for the M2 (show) condition."),
    ("2202.12837", None, "https://arxiv.org/abs/2202.12837", "Rethinking the Role of Demonstrations: What Makes In-Context Learning Work?", "Sewon Min and Xinxi Lyu and Ari Holtzman and Mikel Artetxe and Mike Lewis and Hannaneh Hajishirzi and Luke Zettlemoyer", "EMNLP 2022", 2022, True, ["Q1"], True, "Demonstration format/distribution drives ICL as much as content; motivates the clean XML-delimited, register-matched M2 exemplars."),
    ("2305.04091", None, "https://arxiv.org/abs/2305.04091", "Plan-and-Solve Prompting: Improving Zero-Shot Chain-of-Thought Reasoning by Large Language Models", "Lei Wang and Wanyu Xu and Yihuai Lan and Zhiqiang Hu and Yunshi Lan and Roy Ka-Wei Lee and Ee-Peng Lim", "ACL 2023", 2023, True, ["Q1"], True, "Plan-then-write / decomposition method behind the M3 condition; no news-specific plan template exists, so M3 adapts it to journalism's inverted-pyramid (5 W's) schema."),
    ("2303.17651", None, "https://arxiv.org/abs/2303.17651", "Self-Refine: Iterative Refinement with Self-Feedback", "Aman Madaan and Niket Tandon and Prakhar Gupta and others", "NeurIPS 2023", 2023, True, ["Q1"], True, "The init/feedback/refine structure of the M4 condition; adopted as structure with qualitative (non-numeric) news feedback, deliberately dropping the paper's numeric rubric."),
    ("2310.01798", None, "https://arxiv.org/abs/2310.01798", "Large Language Models Cannot Self-Correct Reasoning Yet", "Jie Huang and Xinyun Chen and Swaroop Mishra and Huaixiu Steven Zheng and Adams Wei Yu and Xinying Song and Denny Zhou", "ICLR 2024", 2024, True, ["Q1"], False, "Caveat that intrinsic self-correction fails for reasoning; motivates treating M4 style/rhythm self-refine as the friendlier case and the self-leniency guard."),
    ("2307.03172", None, "https://arxiv.org/abs/2307.03172", "Lost in the Middle: How Language Models Use Long Contexts", "Nelson F. Liu and Kevin Lin and John Hewitt and Ashwin Paranjape and Michele Bevilacqua and Fabio Petroni and Percy Liang", "TACL 2024", 2024, True, ["Q1"], True, "U-shaped primacy/recency; motivates the M1 end re-anchor and the M2 exemplar ordering (strongest first and last)."),

    # ===== Formula citations: point-process burstiness, classical stylometry, ablation corpus =====
    (None, "10.1209/0295-5075/81/48002", "https://doi.org/10.1209/0295-5075/81/48002", "Burstiness and memory in complex systems", "Goh, Kwang-Il and Barabási, Albert-László", "EPL (Europhysics Letters)", 2008, True, ["Metric"], False, "The Goh-Barabási burstiness coefficient B=(sigma-mu)/(sigma+mu), the point-process measure we adapt to sentence lengths as the locked B_n core."),
    (None, "10.1103/PhysRevE.94.032311", "https://doi.org/10.1103/PhysRevE.94.032311", "Measuring burstiness for finite event sequences", "Kim, Eun-Kyeong and Jo, Hang-Hyun", "Physical Review E", 2016, True, ["Metric"], False, "Finite-n bias correction for the burstiness coefficient; this is B_n at the short document lengths real text gives."),
    (None, None, "https://ui.adsabs.harvard.edu/abs/1912vamu.book.....G/abstract", "Variabilità e Mutabilità", "Gini, Corrado", "book:C. Cuppini, Bologna", 1912, True, ["Metric"], False, "Origin of the Gini coefficient; reported as the scale-free robustness check that concurs with B_n at r~0.95."),
    (None, None, "https://pure.mpg.de/pubman/item/item_2407783_2/component/file_2407782/Yule_1939_On_Sentence_Lenght_Biometrika_1939.pdf", "On sentence-length as a statistical characteristic of style in prose", "Yule, G. Udny", "Biometrika", 1939, True, ["Metric"], False, "Classical sentence-length stylometry; positions B_n honestly as a bounded reparametrization of the coefficient of variation, a known-weak descriptor."),
    (None, None, "https://academic.oup.com/biomet/article-pdf/31/3-4/356/499025/31-3-4-356.pdf", "A note on the statistical analysis of sentence-length as a criterion of literary style", "Williams, C. B.", "Biometrika", 1940, True, ["Metric"], False, "Classical sentence-length stylometry (with Yule); the descriptor is old and weak on its own, so the novelty is the in-generation control, not the statistic."),
    (None, None, "https://en.wikinews.org", "Wikinews: free-content news source (English, 2016-2021)", "Wikinews", None, 2021, False, ["Data"], False, "Modern human news corpus (English, 2016-2021, CC BY 2.5); the era-controlled human side of the matched human-vs-AI ablation."),
]

# Findings (linked to sessions; many can cite multiple papers)
PASS1_2_FINDINGS = [
    ("Q4", "novelty-bar", "high", "The 'burstiness LoRA' steering mechanism already exists for OTHER style axes (sentiment, persona, authorship). Novelty bar = apply to rhythm + personal fingerprinting + perception validation, NOT invent the mechanism.", ["2402.01618","2503.05213","2408.15666"]),
    ("Q5", "competing-work", "high", "Tarım & Onan 2025 published the first systematic stylometric burstiness comparison (diffusion vs autoregressive). Must cite and position against, not ignore.", ["2507.10475"]),
    ("Q5", "gap", "high", "GPTZero's burstiness operationalization (Tian 2023) is a blog post, not peer-reviewed. This IS the formalization gap the Burstiness Engine identifies.", []),
    ("Q3", "general", "high", "Empirically confirmed: AI text style measurably shifts across model generations, detection rates drop with newer models.", ["2307.09009","2509.22055"]),
    ("TTS-C", "perception", "high", "Bakkouche 2025 perception study: listeners do NOT easily perceive humans and AI clones as the same person — prosody is the discriminator. Direct precedent for Author A's perception hypothesis.", []),
    ("Bio,Arch", "methodology", "high", "Caucheteux et al. (Nature Human Behaviour 2023) show brain uses long-range hierarchical predictions matching LM architecture — the strongest single bridge between Vaswani and biology.", ["2111.14232"]),
    ("Q1", "gap", "high", "Prompt-engineering ceiling for distributional stylistic control is UNDER-PUBLISHED. The negative-result paper Author A proposes is itself a publishable contribution.", []),
]

PASS3_FINDINGS = [
    ("Q5,Q3", "competing-work", "high", "DivEye (arXiv:2509.18880, Sep 2025) captures how unpredictability FLUCTUATES across text via surprisal-based features. This is the most direct 2025 burstiness-adjacent detection paper. Must be in Author A's prior-art section.", ["2509.18880"]),
    ("TTS-A,Q2", "methodology", "high", "EMNLP 2025 main 'Towards Controllable Speech Synthesis in the Era of LLMs' (Lee et al.) is the unified TTS+LLM control framework. DiTTo-TTS controls speech rate via latent-length prediction — direct precedent for in-generation rhythm conditioning.", []),
    ("Q4,Q6", "methodology", "high", "Plug-and-Play LLM Fingerprinting (arXiv:2605.18474) generates LoRA params as variable-length sequences. This is the precedent for GENERATING personalized burstiness LoRAs from a user sample, not just training one.", ["2605.18474"]),
    ("Q2,Q4", "methodology", "medium", "'From Weights to Activations' (arXiv:2604.14090) positions activation steering as the 2025/26 frontier. the project should explicitly choose between weight-space (LoRA) and activation-space (steering vectors) and justify.", ["2604.14090"]),
    ("Q4,TTS-A", "methodology", "medium", "AgentSteerTTS (arXiv:2605.17583) multi-agent closed-loop steering shows the field moving toward composed-controller systems. Burstiness Engine could be one controller in such a system.", []),
]

PASS4_FINDINGS = [
    ("TTS-B", "resolution", "high", "RESOLVED: CTRL-P is a distinct paper (arXiv:2106.08352, Ctrl-P: Temporal Control of Prosodic Variation, Interspeech 2021), NOT Raitio 2020. Closes the Pass-3 open action. Per Author A's scope it anchors Phase 2 (voice personalization), not the core paper.", ["2106.08352"]),
    ("Q1", "competing-work", "high", "Q1 is no longer empty: 'Benchmark of Stylistic Variation in LLM-Generated Texts' (2509.10179) measures variation across 16 frontier models + prompts. It does NOT frame this as a control ceiling vs a distributional target, so the Q1 wedge survives — but must now cite and differentiate.", ["2509.10179"]),
    ("Q1,Q6", "methodology", "high", "'LLMs Still Struggle to Imitate Implicit Writing Styles' (2509.14543) shows prompt-only personalized-style imitation fails. This is the strongest single motivation for the model-level (LoRA/steering) approach over prompting.", ["2509.14543"]),
    ("Q1", "methodology", "medium", "Measure burstiness only among quality-passing generations (effective semantic diversity, 2504.12522) so the Q1 experiment does not reward high-variance incoherence.", ["2504.12522"]),
    ("Q7", "gap", "high", "Q7 remains a genuine gap — no dedicated paper treats punctuation/paragraph as a burstiness proxy. Onegin time-series (2604.20221) gives a method: model segmentation as a symbolic time series for a timing-free proxy. Like Q1, a targeted standalone contribution.", ["2604.20221"]),
]

LEARNINGS = [
    ("methodology", "Run real Firecrawl academic searches; ResearchGravity's delegate_research is a stub that returns hollow 100% completes.", "Pass 1 chain-a360b2b3619b returned 'completed' in 1 second routed to insight_review + webhook_test — no papers retrieved.", "Always use Firecrawl --categories research as the actual fetcher; use ResearchGravity only as the INDEX layer."),
    ("methodology", "Time-filter cutting-edge queries with --tbs qdr:y for last-12-months. Default arXiv search is undated and surfaces old work.", "Pass 3 only worked because of --tbs qdr:y; without it the same queries surface 2020-2023 papers.", "Every new-pass run should include --tbs qdr:y or qdr:m by default; explicitly opt out for historical sweeps."),
    ("methodology", "Add as URL sources to NotebookLM, not arbitrary scraped PDFs. Wrong arXiv ID → wrong paper ingested silently.", "Pass 2 added arXiv:2208.07814 (jet physics) thinking it was Caucheteux — fixed by re-search.", "VERIFY arxiv ID matches the paper title BEFORE source_add. Search-then-add, never type-then-add."),
    ("methodology", "Avoid PMC URLs in source_add — they hit reCAPTCHA and ingest the captcha page as 'source'.", "PMC10038805 was added and the source title showed 'Checking your browser - reCAPTCHA'.", "Prefer arXiv preprint over PMC final when both exist; or use SciHub/researcher-portal URLs."),
    ("novelty-bar", "the project novelty is the COMPOSITE (rhythm-target + personal fingerprinting + perception validation), not any single mechanism. Each ingredient has 2024-2026 precedent.", "Style Vectors (2024), StyleVector (2025), Bakkouche (2025), DivEye (2025), DiTTo-TTS (2025) collectively cover the building blocks.", "Frame paper as 'composing established mechanisms onto a new target with TTS-derived validation', not 'inventing burstiness steering'."),
    ("competing", "Two competing papers are now live: Tarım & Onan 2025 (stylometric burstiness comparison) and DivEye Sep 2025 (surprisal-based diversity detection).", "Both published 2025, both treat burstiness/diversity as central. the project ships into a crowded room.", "Cite both in the related-work section; differentiate on the in-generation CONTROL angle, not the measurement angle."),
    ("perception", "Bakkouche 2025 + 'reduced F0 variation lowers naturalness' from ResearchGate 396811851 = direct evidence that suppressed prosodic variance harms perception. Strong analogy to suppressed burstiness in text.", "If TTS listeners notice suppressed variance, text readers likely do too — testable hypothesis with Bakkouche's methodology adapted.", "Use Bakkouche's experimental design as the template for Author A's text-perception study."),
    ("gap", "Q1 (prompt-engineering ceiling for distributional stylistic control) is genuinely under-published. The systematic-negative-result paper does not exist yet.", "8 Firecrawl queries surfaced zero peer-reviewed papers measuring prompt-only ceiling against distributional targets like sentence-length variance.", "Treat Q1 as a publishable contribution in itself OR as the motivation section of the main paper."),
    ("verification", "RESOLVED: the Amodei dissertation Author B cited is real and valid. Amodei (2011), 'Network-Scale Electrophysiology: Measuring and Understanding the Collective Behavior of Neural Circuits', Princeton Ph.D. (Physics dept, biophysics; advisors Berry and Bialek). The earlier claim that it did not exist / was condensed-matter physics was wrong.", "Verified against the Princeton dataspace record (dsp013f462544k). The confusion: a biophysics thesis housed in the Physics department, using MaxEnt/Ising machinery on biological neural circuits; 'Physics' was misread as condensed matter and 'neural networks' as artificial nets. See research/CITATION-AMODEI-RESOLVED.md.", "Usable as a SUPPORTING bio-bridge citation (collective distributional behavior emerging from simple elements), never load-bearing; the load-bearing bridge stays Caucheteux (Nature Human Behaviour 2023) + eLife predictive coding."),
    ("scope", "CANONICAL SCOPE (from Author A's email thread, May 21-28 2026): title = 'the project: Modeling Human Rhythmic Patterns in Language Generation'. Spine = prompt-level control as baseline (show where it breaks) → model-level steering (auxiliary rhythm model / LoRA) as the answer. TTS is PHASE 2, not core. Emotion out of scope unless a dataset already exists.", "Author A explicitly flagged the original 'Engineering Synthetic Human Rhythm' title for ethics, said the TTS prosody angle 'makes the surface too big, we'd lose depth', and chose model-level as the real contribution with prompt-level as baseline.", "All synthesis and the paper outline follow this spine. Do not foreground TTS. The deliverable Author A is waiting on is shareable ResearchGravity results she can read independently before a sync call."),
    ("verification", "Citation metadata in seed.py drifted from the real papers: 24 entries had no author (rendered '(arXiv, 2025)' under plainnat author-year), author strings were comma-separated not BibTeX 'and'-separated, and one entry was fully fabricated — bakkouche2025prosodic pointed to DOI 10.1016/j.tics.2025.03.001 which is actually Dehaene et al. 'Origins of numbers', not a prosody study.", "Every arXiv ID verified against the arXiv API and every DOI/URL against Crossref/NCBI/eLife; all 35 arXiv IDs were real but author/title/year often wrong; the real Bakkouche paper is 'Finding the Human Voice in AI' (Interspeech 2025, doi 10.21437/interspeech.2025-947).", "Never hand-type citation metadata. Verify title+authors+year against the source API before adding to seed.py. gen-bibtex now warns on empty authors and honors paper/citekeys.lock.json so correcting metadata never silently renames a \\cite key. Re-run the arXiv/Crossref verification before any submission."),
]


def get_conn(reset=False):
    SQLITE_PATH.parent.mkdir(parents=True, exist_ok=True)
    if reset and SQLITE_PATH.exists():
        SQLITE_PATH.unlink()
    conn = sqlite3.connect(SQLITE_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def apply_schema(conn):
    with open(SCHEMA, encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.commit()


def upsert_paper(conn, p):
    arxiv, doi, url, title, authors, venue, year, peer, axes, bridge, notes = p
    cur = conn.execute(
        "INSERT INTO papers (arxiv_id, doi, url, title, authors, venue, year, peer_reviewed, relevance_notes) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(url) DO UPDATE SET title=excluded.title, authors=excluded.authors, "
        "venue=excluded.venue, year=excluded.year, peer_reviewed=excluded.peer_reviewed, "
        "relevance_notes=excluded.relevance_notes RETURNING id",
        (arxiv, doi, url, title, authors, venue, year, 1 if peer else 0, notes)
    )
    paper_id = cur.fetchone()[0]
    for axis in axes:
        conn.execute(
            "INSERT OR REPLACE INTO paper_axes (paper_id, axis, bridge_paper) VALUES (?, ?, ?)",
            (paper_id, axis, 1 if bridge else 0)
        )
    return paper_id


def insert_session(conn, label, notes):
    cur = conn.execute(
        "INSERT INTO sessions (label, notes, notebook_id) VALUES (?, ?, ?) RETURNING id",
        (label, notes, "6cf8ec76-c2eb-4a67-93b6-f474e5dc1818")
    )
    return cur.fetchone()[0]


def insert_queries(conn, session_id, queries):
    for axis, qtext, tbs, path in queries:
        full_path = ROOT / path if path else None
        count = None
        if full_path and full_path.exists():
            with open(full_path, encoding="utf-8") as f:
                data = json.load(f)
            count = len((data.get("data") or {}).get("web") or [])
        conn.execute(
            "INSERT INTO queries (session_id, axis, query_text, time_filter, raw_output_path, result_count) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (session_id, axis, qtext, tbs, path, count)
        )


def insert_findings(conn, session_id, findings, paper_id_by_arxiv):
    for axis, ftype, conf, ftext, paper_arxivs in findings:
        cur = conn.execute(
            "INSERT INTO findings (session_id, axis, finding_type, confidence, finding_text) "
            "VALUES (?, ?, ?, ?, ?) RETURNING id",
            (session_id, axis, ftype, conf, ftext)
        )
        fid = cur.fetchone()[0]
        for arxiv in paper_arxivs:
            pid = paper_id_by_arxiv.get(arxiv)
            if pid:
                conn.execute(
                    "INSERT OR IGNORE INTO finding_papers (finding_id, paper_id) VALUES (?, ?)",
                    (fid, pid)
                )


def insert_learnings(conn, learnings, session_ids):
    sess_json = json.dumps(session_ids)
    for cat, stmt, why, how in learnings:
        conn.execute(
            "INSERT INTO learnings (category, statement, why, how_to_apply, derived_from_sessions) "
            "VALUES (?, ?, ?, ?, ?)",
            (cat, stmt, why, how, sess_json)
        )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true", help="Drop DB and recreate")
    args = ap.parse_args()

    conn = get_conn(reset=args.reset)
    apply_schema(conn)

    # Load all papers
    arxiv_to_id = {}
    for p in PAPERS:
        pid = upsert_paper(conn, p)
        if p[0]:
            arxiv_to_id[p[0]] = pid

    # Pass 1+2 baseline session
    s12 = insert_session(conn, "pass-1-2-baseline", "Initial 8-query Firecrawl sweep of academic literature mapped to Author A's 7 questions + TTS + Bio anchors.")
    insert_queries(conn, s12, PASS1_2_QUERIES)
    insert_findings(conn, s12, PASS1_2_FINDINGS, arxiv_to_id)

    # Pass 3 cutting-edge session
    s3 = insert_session(conn, "pass-3-cutting-edge", "Last-12-months arXiv sweep for progression vs baseline. A/B against pass 1+2.")
    insert_queries(conn, s3, PASS3_QUERIES)
    insert_findings(conn, s3, PASS3_FINDINGS, arxiv_to_id)

    # Pass 4 gap-closing session
    s4 = insert_session(conn, "pass-4-gap-closing", "Targeted Firecrawl sweep closing Q1 prompt-ceiling, Q7 punctuation-proxy, and CTRL-P verification. Re-anchored to Author A's canonical scope (prompt-baseline → model-level; TTS Phase 2).")
    insert_queries(conn, s4, PASS4_QUERIES)
    insert_findings(conn, s4, PASS4_FINDINGS, arxiv_to_id)

    # Learnings span all sessions
    insert_learnings(conn, LEARNINGS, [s12, s3, s4])

    conn.commit()

    counts = {
        "papers": conn.execute("SELECT COUNT(*) FROM papers").fetchone()[0],
        "queries": conn.execute("SELECT COUNT(*) FROM queries").fetchone()[0],
        "findings": conn.execute("SELECT COUNT(*) FROM findings").fetchone()[0],
        "learnings": conn.execute("SELECT COUNT(*) FROM learnings").fetchone()[0],
        "paper_axes": conn.execute("SELECT COUNT(*) FROM paper_axes").fetchone()[0],
    }
    print(f"Seeded {SQLITE_PATH}")
    for k, v in counts.items():
        print(f"  {k:14s} {v}")
    conn.close()


if __name__ == "__main__":
    main()
